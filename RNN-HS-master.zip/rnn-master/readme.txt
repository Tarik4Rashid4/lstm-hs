
Cite as :

Tarik A. Rashid, Polla Fattah and Delan K. Awlaa (2018), 
Using Accuracy Measure for Improving the Training of LSTM with Metaheuristic Algorithms, 
Procedia Computer Science 140, 324�333, https://doi.org/10.1016/j.procs.2018.10.307